contract('erc20token', function(accounts) {
  it("should assert true", function(done) {
    var erc20token = erc20token.deployed();
    assert.isTrue(true);
    done();
  });
});
